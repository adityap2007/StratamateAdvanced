/** @type {import('next').NextConfig} */
// Trigger new deployment
const nextConfig = {
  output: 'standalone'
}

module.exports = nextConfig 